import React from "react";
import "../Css/Live.css";
import live from "../Images/live.png";
import live2 from "../Images/live2.png";
import img20 from "../Images/ONN1.png";
import img23 from "../Images/Course-Blue.png";

function Live() {
  return (
    <>
      <section id="Live" className="class">
        <img src={img20} alt="" className="img-live" />
      </section>

      <section id="Live1">
        <div className="Live" data-aos="fade-up">
          <div className="row live-container">
            <div className="col-lg-6 content order-lg-1 order-2">
              <div className="icon-box" data-aos="fade-up" data-aos-delay={100}>
                <p className="description">
                  <p>
                    ‘Sankhyana’ in Sanskrit means ‘Numeration’ which in-turn
                    means the process or action of calculating by assigning
                    numbers to something. At Sankhyana Consultancy Services we
                    visualize business scenarios’ by assigning numbers and then
                    use relevant Statistical Models to glean out meaningful and
                    actionable insights enabling businesses to take data driven
                    decisions.
                  </p>
                  Our Programs Are Designed To Empower Individual To Meet
                  Industry Demands, Fuel Enthusiasm For Higher Education And
                  Professional Training.
                </p>
              </div>
              <div className="icon-box" data-aos="fade-up" data-aos-delay={200}>
                <p className="description">
                  We Provide a wide Range Of Opportunities To Assist
                  Organizations Obtain Meaningful And Actionable Analytical
                  Insights From Their Data.
                </p>
                <p class="text-center float-md-start">
                  <button class="btn btn-primary" type="submit">
                    Download Broucher
                  </button>
                </p>
              </div>
            </div>

            <div
              className="col-lg-6 background order-lg-2 text-center"
              data-aos="zoom-in"
            >
              <img src={live} className="img-fluid" alt="" />
            </div>
          </div>
        </div>
      </section>

      <section id="Live2">
        <div className="row about-extra">
          <div
            className="col-lg-6 aos-init aos-animate text-center"
            data-aos="zoom-in"
          >
            <img src={live2} className="img-fluid" alt="" />
          </div>
          <div
            className="col-lg-6 pt-5 pt-lg-0 aos-init aos-animate"
            data-aos="fade-left"
          >
            <div className="icon-box" data-aos="fade-up" data-aos-delay={100}>
              <p align="justify">
                More than 65 Clients Joined us and we live up to our Clients
                Expectations. We are successfully done approx 78 Projects all
                over the world and make it easy for our clients. Sankhyana is
                India's largest ed-tech company and the creator of India's most
                loved learning website. Launched in 2009, we offer highly
                personalized and effective learning programs and 3.5 million
                paid subscriptions, Sankhyana has become one of the most
                preferred education platforms across the globe.
              </p>
            </div>
            <div className="col-sm-12 col-md-12">
              <p class="text-center float-md-start">
                <button class="btn btn-primary" type="submit">
                  Explore The Cateloge
                </button>
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="Live3">
        <div class="cadl-container">
          <div class="row">
            <div class="col-md-4 col-sm-12">
              <div class="cadl">
                <img src={img23} className="img-fluid" alt="" />
                <div class="caRd-body">
                  <h5>Live Web</h5>
                  <p class="card-text">
                    Join our live web sessions for real-time, interactive
                    learning from anywhere.
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="cadl">
                <img src={img23} className="img-fluid" alt="" />
                <div class="caRd-body">
                  <h5>Free Demos</h5>
                  <p class="card-text">
                    Experience our offerings with free demos to explore their
                    capabilities and benefits.
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="cadl">
                <img src={img23} className="img-fluid" alt="" />
                <div class="caRd-body">
                  <h5>Classroom</h5>
                  <p class="card-text">
                    Engage in learning with our classroom courses for a
                    comprehensive educational.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="Live4">
        <div class="hor">
          <div class="card-ho">
            <h5 class="card-title">Special title treatment</h5>
            <p class="cad-text text-align-justify">
              With supporting text below as a natural lead-in to additional
              content.With supporting text below as a natural lead-in to
              additional content. With supporting text below as a natural
              lead-in to additional content.With supporting text below as a
              natural lead-in to additional content.
            </p>
            <p class="text-center float-md-start">
              <button class="btn btn-primary" type="submit">
                MoreInfo
              </button>
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
export default Live;

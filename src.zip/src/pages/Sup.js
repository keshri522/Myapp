import React, { useState } from "react";
// import axios from "axios";
import emailjs from "@emailjs/browser";
import "../Css/Sup.css";
// import { response } from "express";

// import sup from '../Images/course.png';

function Sup() {
  const [name, nameSet] = useState("");
  const [email, emailSet] = useState("");
  const [message, messageSet] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const serviceId = "service_enxzdfe";
    const templateId = "template_fd6zn3g";
    const publicKey = "Fv8gRJuUmMHQuyxZM";

    const templateParams = {
      from_name: name,
      to_email: email,
      to_name: "Sankhayana",
      message: message,
    };

    emailjs
      .send(serviceId, templateId, templateParams, publicKey)
      .then((response) => {
        console.log("success", response);
        nameSet("");
        emailSet("");
        // console.log(email);
        messageSet("");
        alert("Message send successfully...!")
      })

      .catch((error) => {
        console.log("error", error);
      });
  };

  return (
    <>
      <div class="support col-sm-6 col-md-12">
        <div class="rowS">
          <div class="colS">
            <h5>Office Locations</h5>
            <h6>Address</h6>
            <p>
              #1675,2nd Floor,Nehru Road,Near Kammanahalli, Bangaluru-560084
            </p>

            <h5>Contact Us</h5>
            <h6>Mail - info@sankhyana.com </h6>
            {/* <p>Phone - 8951836403</p> */}
            <p>Phone - 9591295524 </p>

            <h5>Openning Hours</h5>
            <p>Mon-Sun : 9:00am - 07:00pm</p>
          </div>
          <div class="colS"></div>
          <div class="colS">
            <form onSubmit={handleSubmit}>
              <div class="form-row">
                <div class="form-group col-md-12">
                  <i class="fas fa-envelope fa-lg me- fa-fw"></i>
                  {/* <label for="inputEmail4">Email</label>  */}
                  <input
                    type="email"
                    class="form-control"
                    id="inputEmail4"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => emailSet(e.target.value)}
                  />
                </div>
                <div class="form-group col-md-12">
                  {" "}
                  <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                  {/* <label for="inputPassword4">Password</label> */}
                  <input
                    type="text"
                    class="form-control"
                    id="inputname4"
                    placeholder="Enter Your Name"
                    value={name}
                    onChange={(e) => nameSet(e.target.value)}
                  />
                </div>
              </div>
              <div class="form-group col-md-12">
                {" "}
                <i class="fas fa-phone fa-lg me-3 fa-fw"></i>
                {/* <label for="inputAddress">Mobile</label> */}
                <input
                  type="text"
                  class="form-control"
                  id="inputMobile"
                  placeholder="Please Enter Your Mobile No."
                  value={message}
                  onChange={(e) => messageSet(e.target.value)}
                />
              </div>
              <div class="mb-4 col-md-12">
                <select class="select">
                  <option value="1" disabled>
                    Select Options
                  </option>
                  <option value="2">Training</option>
                  <option value="3">Consulting</option>
                  <option value="4">Analytics</option>
                </select>
              </div>

              <div class="form-group">
                <div class="form-check">
                  <input
                    class="form-check-input"
                    type="checkbox"
                    id="gridCheck"
                  />
                  <label class="form-check-label" for="gridCheck">
                    Check me out
                  </label>
                </div>
              </div>
              {/* <div class="mb-4 col-md-12"> */}
              <button type="submit" class="primary">
                Submit
              </button>
              {/* </div> */}
            </form>
          </div>
        </div>
      </div>

      {/* <div className="scontainer">
        <div className="bg-light">
          <div className="row">
            <div className="col-lg-8 col-md-12 p-5 bg-white rounded-3">
              <div className="row">
                <div className="col-md-4">
                  <div
                    className={`cardT ${activeCardT === "Training" ? "active" : ""}`}
                    onClick={() => handleCardTClick("Training")}
                  >
                    <div className="cardT-body">
                   
                      <h5 className="cardT-title">TRAINING</h5>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div
                    className={`cardT ${activeCardT === "Analytics" ? "active" : ""}`}
                    onClick={() => handleCardTClick("Analytics")}
                  >
                    <div className="cardT-body">
                      
                      <h5 className="cardT-title">ANALYTICS</h5>
                      <p className="cardT-text">
                      </p>
                     
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div
                    className={`cardT ${
                      activeCardT === "Consultancy" ? "active" : ""
                    }`}
                    onClick={() => handleCardTClick("Consultancy")}
                  >
                    <div className="cardT-body">
                    
                      <h5 className="cardT-title">CONSULTANCY</h5>
                      <p className="cardT-text">
                        
                      </p>
                      
                    </div>
                  </div>
                </div>
                {activeCardT === "Training" && (
                  <form className="row mb-3" onSubmit={handleSubmit}>
                   
                      
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="first name"
                        type="text"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="last name"
                        type="text"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="E-mail"
                        type="text"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="Phone"
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md">
                      <textarea
                        required
                        placeholder="Message Type Here"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        cols="30"
                        rows="1"
                      ></textarea>
                    </div>
                    <div className="col-md-12 g-4">
                        <div class="dropdown">
                            <h5>What service You need ?</h5>
                            <select
                                  className="select form-control-lg my-2"
                                  onChange={handleServiceChange}
                             >
                              <option value="1">
                                Choose Option For Training
                              </option>
                              <optgroup label="SAS Courses">
                                <option value="2">Base SAS</option>
                                <option value="3">Clinic SAS</option>
                                <option value="5">Advance SAS</option>
                                <option value="6">Viya SAS</option>
                              </optgroup>
                              <optgroup label="Data Science Course">
                                <option value="7">Data Mining with Python</option>
                                <option value="8">Statistics with Python</option>
                                <option value="9">Artificial Intelligence</option>
                              </optgroup>
                              <optgroup label="Full Stack Courses">
                                <option value="10">Real-time projects</option>
                                <option value="11">Gain Problem-solving skills</option>
                                <option value="12">Improved hiring potential</option>
                                <option value="13">Frontend and Backend Tools</option>
                              </optgroup>
                              <optgroup label="Intership">
                                <option value="14">Clinical SAS</option>
                                <option value="15">Full Stack Developer</option>
                                <option value="14">Finance Intern</option>
                                <option value="15">Data Engineer</option>
                              </optgroup>
                              <optgroup label="Others"></optgroup>
                            </select>
                          </div> 
                      </div>
                    <div className="text-end mt-4">
                      <input
                        className="btn px-4 py-3 btn-outline-dark"
                        type="submit"
                        value="Send Message"
                      />
                    </div>
                  </form>
                )}
                {activeCardT === "Analytics" && (
                  <form className="row mb-3" onSubmit={handleSubmit}>
                  
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="first name"
                        type="text"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleInputChange}
                      />
                    </div>
                  
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="last name"
                        type="text"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="E-mail"
                        type="text"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="Phone"
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md">
                      <textarea
                        required
                        placeholder="Message Type Here"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        cols="30"
                        rows="1"
                      ></textarea>
                    </div>
                      <div className="col-md-12 g-4">
                      <div class="dropdown">
                            <h5>What service You need ?</h5>                          
                          <select class="select form-control-lg my-2">
                         
                              <option value="1">
                                Choose option for Analytics
                              </option>
                              <option value="2">Banking</option>
                              <option value="3">Financial Services</option>
                              <option value="4">Cloud Service</option>
                              <option value="6">Data & Analytics</option>
                              <option value="7">Automative</option>
                              <option value="8">Retail</option>
                              <option value="9">Social Media</option>
                              <option value="10">Life Science</option>
                              <option value="11">Healthcare</option>
                              <option value="12">Manufacturing</option>
                              <option value="13">Insurance</option>
                              <option value="14">Energy</option>
                              <option value="15">Forest</option>
                              <option value="16">Consulting & Outsourcing</option>
                              <option value="17">Government</option>
                        </select>
                      </div>
                    </div>
                    <div className="text-end mt-4">
                      <input
                        className="btn px-4 py-3 btn-outline-dark"
                        type="submit"
                        value="Send Message"
                      />
                    </div>
                  </form>
                )}
                {activeCardT === "Consultancy" && (
                  <form className="row mb-3" onSubmit={handleSubmit}>
                
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="first name"
                        type="text"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleInputChange}
                      />
                    </div>
                   
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="last name"
                        type="text"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="E-mail"
                        type="text"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md-6 p-3">
                      <input
                        required
                        placeholder="Phone"
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="col-md">
                      <textarea
                        required
                        placeholder="Message Type Here"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        cols="30"
                        rows="1"
                      ></textarea>
                    </div>

                    <div className="col-md-12 g-4">
                    <div class="dropdown">
                            <h5>What service You need ?</h5>
                        <select class="select form-control-lg my-2">
                              <option value="1">
                                Choose option for Consultancy
                              </option>
                              <option value="2">Permanent Staffing</option>
                              <option value="3">Contract Staffing</option>
                              <option value="4">Campus Recruitment</option>
                              <option value="5">Others</option>
                            </select>
                       
                    </div>
                    </div>
                    <div className="text-end mt-4">
                      <input
                        className="btn px-4 py-3 btn-outline-dark"
                        type="submit"
                        value="Send Message"
                      />
                    </div>
                  </form>
                )}
              </div>
            </div>
            <div className="col-lg-4 col-md-12 text-white aside px-4 py-5">
              <div className="mb-5">
                <h1 className="h3">Contact Information</h1>
                <p className="opacity-50">
                  <small>
                    Fill out the form, and we will get back to you within 24
                    hours
                  </small>
                </p>
              </div>
              <div className="d-flex flex-column px-0">
                <ul className="m-0 p-0">
                  <li className="d-flex justify-content-start align-items-center mb-4">
                    <span className="opacity-50 d-flex align-items-center me-3 fs-2">
                      <i className="fa-solid fa-phone"></i>
                    </span>
                    <span>+91-8048147185/86</span>
                  </li>
                  <li className="d-flex align-items-center mb-4">
                    <span className="opacity-50 d-flex align-items-center me-3 fs-2">
                      <i className="fa-regular fa-message"></i>
                    </span>
                    <span>info@sankhyana.com</span>
                  </li>
                  <li className="d-flex justify-content-start align-items-center mb-4">
                    <span className="opacity-50 d-flex align-items-center me-3 fs-2">
                      <i className="fa-solid fa-house"></i>
                    </span>
                    <span>
                      <h6>
                        <u>Head Office</u>
                      </h6>
                      Address: #1678,
                      <br />
                      2nd Floor 'A' 60 Feet,
                      <br />
                      Nehru Road Opp HDFC ATM,
                      <br />
                      Near Kullappa Circle,
                      <br />
                      Kammanahalli
                      <br />
                      Bengaluru-560084
                    </span>
                  
                  </li>
                  <li className="d-flex justify-content-start align-items-center mb-4">
                    <span className="opacity-50 d-flex align-items-center me-3 fs-2">
                      <i className="fa-solid fa-house"></i>
                    </span>
                    <span>
                

                      <h6>
                        <u>Branch Office</u>
                      </h6>
                      Dehri-On-Sone,
                      <br />
                      2nd Floor,Amber Hotel;
                      <br />
                      Station Road,
                      <br />
                   
                      Bihar-821305;
                    </span>
                  
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div> */}

      <div className="col-sm-6 col-md-12">
        <div className="mb-4">
        {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7961269.273807664!2d67.88155282500004!3d13.014102199999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae17234042f279%3A0x2513ca5bcfd3ba26!2sSankhyana%20Consultancy%20Services%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1700222218821!5m2!1sen!2sin" width="600" height="450"" iframe> */}
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7961269.273807664!2d67.88155282500004!3d13.014102199999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae17234042f279%3A0x2513ca5bcfd3ba26!2sSankhyana%20Consultancy%20Services%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1700222218821!5m2!1sen!2sin" width="100%" height="450"></iframe>
        </div>
       
      </div>
    </>
  );
}

export default Sup;
